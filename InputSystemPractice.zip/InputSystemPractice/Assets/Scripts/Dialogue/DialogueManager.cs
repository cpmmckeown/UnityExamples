using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Ink.Runtime;
using UnityEngine.EventSystems;

public class DialogueManager : MonoBehaviour
{
    
    [Header("Dialogue UI")]
    [SerializeField] private GameObject dialoguePanel;
    [SerializeField] private GameObject continueArrow;
    [SerializeField] private TextMeshProUGUI dialogueText;
    [Header("Choices UI")]
    [SerializeField] private GameObject[] choices;
    private TextMeshProUGUI[] choicesText;
    NewControls controls;
    private Story currentStory;

    public bool dialogueIsPlaying { get; private set; }

    //A static instance of this class
    private static DialogueManager instance;


    private void Awake()
    {
        if (instance != null)
        {
            Debug.LogWarning("More than 1 Dialogue Manager in the scene");
        }
        //initalises an instance of this class if only one exists
        instance = this;

        if (controls == null)
        {
            controls = new NewControls();
        }
        controls.Controls.Enable();
    }

    public static DialogueManager GetInstance()
    {
        //returns the instance of this class 
        return instance;
    }

    private void Start()
    {
        dialogueIsPlaying = false;
        dialoguePanel.SetActive(false);
        //dialogueText.enabled = false; //Don't need these switches because child of dialoguePanel
        continueArrow.SetActive(false);

        //Get all choices text
        choicesText = new TextMeshProUGUI[choices.Length];
        int index = 0;
        foreach (GameObject choice in choices)
        {
            choicesText[index] = choice.GetComponentInChildren<TextMeshProUGUI>();
            index++;
        }

    }

    private void Update()
    {
        //return right away if no dialogue
        if (!dialogueIsPlaying)
        {
            return;
        }

        //handle continuing to the next line in the dialogue when submit is pressed 
        if (controls.Controls.Action.WasPerformedThisFrame())
        {
            
            ContinueStory();
            if (currentStory.canContinue) 
            { 
                continueArrow.SetActive(true); 
            }
            else continueArrow.SetActive(false);
        }
    }

    public void EnterDialogueMode(TextAsset inkJSON)
    {
        
        currentStory = new Story(inkJSON.text);
        dialogueIsPlaying = true;
        dialoguePanel.SetActive(true);
        //dialogueText.enabled=true;
        ContinueStory();
    }

    private IEnumerator ExitDialogueMode()//IENumerator to enable small wait
    {
        yield return new WaitForSeconds(0.2f);//Small wait to prevent button overlap
        
        dialogueIsPlaying = false;
        dialoguePanel.SetActive(false);
        //dialogueText.enabled = false;
        dialogueText.text = "";
    }

    private void ContinueStory()
    //Built in INK method that checks if there's another line
    {
        if (currentStory.canContinue)
        {
            dialogueText.text = currentStory.Continue();
            DisplayChoices();
        }
        else
        {
            //Because Exit Dialogue is IENumerator with a wait, it's a coroutine
            StartCoroutine(ExitDialogueMode());
        }
    }

    private void DisplayChoices()
    {
        List<Choice> currentChoices = currentStory.currentChoices;

        //check to make sure UI can display # of choices
        if (currentChoices.Count > choices.Length)
        {
            Debug.LogError("More choices were given than UI can support ie " + currentChoices.Count);
        }

        //Enable and initialise the choices up to the amount of 
        //choices for this line of dialogue
        int index = 0;
        foreach (Choice choice in currentChoices)
        {
            choices[index].gameObject.SetActive(true);
            choicesText[index].text = choice.text;
            index++;
        }
        //Go through the remaining choices the UI supports and make tsure they're hidden
        for (int i = index; i < choices.Length; i++)
        {
            choices[i].gameObject.SetActive(false);
        }

        StartCoroutine(SelectFirstChoice());
    }

    private IEnumerator SelectFirstChoice() 
    {
        EventSystem.current.SetSelectedGameObject(null);
        yield return new WaitForEndOfFrame();
        EventSystem.current.SetSelectedGameObject(choices[0].gameObject);
    }

    public void MakeChoice(int choiceIndex) 
    {
        currentStory.ChooseChoiceIndex(choiceIndex);
    }
//End
}
