using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Tilemaps;

public class CharCollide : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI dialogueText;
    [SerializeField] TextMeshProUGUI nameText;
    [SerializeField] GameObject dialoguePanel;

    void OnTriggerEnter2D(Collider2D col)
    {
        ShowDialogue("Hello traveller!", "Wizard");
    }

    void OnTriggerExit2D(Collider2D col)
    {
        EndDialogue();
    }


    public void ShowDialogue(string dialogue, string name)
    {
        print("Wizard");
        nameText.text = name;
        dialogueText.text = dialogue;
        dialoguePanel.SetActive(true);
    }

    public void EndDialogue()
    {
        nameText.text = null;
        dialogueText.text = null; ;
        dialoguePanel.SetActive(false);
    }
}
