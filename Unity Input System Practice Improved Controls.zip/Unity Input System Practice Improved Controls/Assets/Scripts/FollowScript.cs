using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowScript : MonoBehaviour
{
    
    private Vector3 velocity = Vector3.zero; //the speed of the camera
    public 
        Transform target; //this is the player that the camera is chasing
    [SerializeField] private Vector3 offset = new Vector3 (0f, 0f, 0f);
    [SerializeField] private float smoothTime = 0.5f; //time it takes for camera to smoothly catch up
    // Update is called once per frame
    void Update()
    {
        /*The follow script works by first defining the subject and an
         * offset to follow*/
        Vector3 targetPosition = target.position + offset;
        /*Then the camera starts to chase after that position and its offset 
         * based on a set time*/
            transform.position =  Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
     }
}

 