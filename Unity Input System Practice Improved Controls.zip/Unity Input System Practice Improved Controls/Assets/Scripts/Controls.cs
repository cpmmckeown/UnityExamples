using UnityEngine;


public class Controls : MonoBehaviour 
{
    [Header("Control Settings")]
    [SerializeField] private float downForce; //the force that pushes the player down mid-jump
    [SerializeField] private float jumpPower; //the power of the player's jump
    [SerializeField] private float maxSpeed; //the player's max movement speed
    [SerializeField] private float movementSpeed; //the player's movement speed, applied incremementally up to the max. 
    

    private NewControls controls;
    

    [Header("Bits and Pieces")]
    public LayerMask Ground;    //layermask for checking jump. Set in the editor because I'm lazy. 
    private Rigidbody2D rb; //reference to a rigid body. This is set to the player object when not in dialogue mode. 
    public SpriteRenderer character;
    public Animator animator;
    bool facingLeft = true;
    Vector3 lastGround = Vector3.zero; //I hope to have a 'Fez' like system where the last ground you touch is what you respawn at. It sort of works! 
    private int GroundCount = 0; //making it so that 1/10 of a second has to occur before grounded counts


    private void Awake()
    {
        if (controls == null)
        {
            controls = new NewControls();
        }
        controls.Controls.Enable();
    }

    public void OnEnable()
    
    {
        //get the reference to the rigidbody
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        /*This nasty, hacky bit of code absolutely ramrods a check
         * into the game to make sure if the player releases the jump button 
         * they get smacked down to earth. 
         * Creates more of that 'Hollow Knight' feel
         */
        if (controls.Controls.Jump.WasReleasedThisFrame())
        {
            print("released");
            Vector2 jumpStop = new Vector2(0f, downForce);
            rb.AddForce(jumpStop);
        }

        if (controls.Controls.Quit.WasPressedThisFrame())
        {
            Quit();
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (DialogueManager.GetInstance().dialogueIsPlaying)
        {
            return;
        }
        else
        {
            if (IsGrounded())
            {
                JumpCharacter();
            }

            //Sets max speed character can accelerate until
            if (Mathf.Abs(rb.velocity.x) < maxSpeed)
            {
                MoveCharacter();
            }

            if (rb.position.y < -10)
            {
                rb.position = lastGround;
            }
            
        }
        
    }

    private void MoveCharacter() 
    {
        
        //Get the movement direction
        var playerMovementDirection = controls.Controls.Move.ReadValue<Vector2>();
        
        //Move the character
        Vector2 force = new Vector2(playerMovementDirection.x * movementSpeed, 0f);
        rb.AddForce(force, ForceMode2D.Impulse);

        WalkAnim();

        //Flip the character
        if (playerMovementDirection.x < 0f && facingLeft)
        { 
            Flip(); 
        }
        if (playerMovementDirection.x > 0f && !facingLeft)
        {
            Flip();
        }
    }

    private void JumpCharacter()
    {
        var playerJump = controls.Controls.Jump.ReadValue<Vector2>();
            Vector2 jumpForce = new Vector2(0f, playerJump.y * jumpPower);
            rb.AddForce(jumpForce, ForceMode2D.Impulse);
    }

    private void WalkAnim()
    {
        if (Mathf.Abs(rb.velocity.x) < 0.5)
        {
            animator.SetBool("isWalking", false);
        }
        else { animator.SetBool("isWalking", true); }
    }
    private void Flip()
    { 
        character.flipX = !character.flipX; //because the character model faces left, this is flipped from what you would think.
        facingLeft = !facingLeft;    
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
       lastGround = col.gameObject.transform.position;
    }

    private void Quit()
    {
            Application.Quit();
       
    }

    //This is my Method that returns a bool based on a physics raycast to check if player is grounded. 
    private bool IsGrounded()
    {
        Vector2 position = gameObject.transform.position;
        Vector2 direction = Vector2.down;
        float distance = 0.35f;
        RaycastHit2D hit = Physics2D.Raycast(position, direction, distance, Ground);

      
        if (GroundCount < 3)
        {
            if (hit.collider != null)
            {
                GroundCount++;
            }
            return false;
        }
        else
        {
            GroundCount = 0;
            return true;
        }
    }

}
