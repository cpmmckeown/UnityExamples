 using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class DialogueTrigger : MonoBehaviour
{
    [Header("Alert")]
    [SerializeField] private GameObject alert;

    [Header("Ink JSON")]
    [SerializeField] private TextAsset inkJSON;

    [Header("Dialogue Area")]

    private bool playerInRange;

    NewControls controls; //Setting up an instance of the controls I set up in the editor
    
    private void Awake()
    {
        playerInRange = false;
        alert.SetActive(false);
        if (controls == null)
        {
            controls = new NewControls();
        }
        controls.Controls.Enable();
    }

    private void Update()
    {
        if (playerInRange&&!DialogueManager.GetInstance().dialogueIsPlaying) 
        {
            alert.SetActive(true);
            if (controls.Controls.Action.WasPressedThisFrame())
            {
                DialogueManager.GetInstance().EnterDialogueMode(inkJSON);
            }

        }
        else { alert.SetActive(false); }
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            playerInRange=true;
        }
    }

    private void OnTriggerExit2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            playerInRange = false;
        }
    }

}
