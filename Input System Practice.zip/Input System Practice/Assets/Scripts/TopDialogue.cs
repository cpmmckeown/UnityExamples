/*This script should use an Ink JSON file to show dialogue based on the actions of the player. Specifically, if the player picks up an object in the game 
world, then the Ink JSON should move on to the next line, with the possibility of adding other features down the line*/


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Ink.Runtime;
using UnityEngine.EventSystems;

public class TopDialogue : MonoBehaviour
{ 
    
    [Header("TopDialogue Display")]
    //[SerializeField] private GameObject topDialoguePanel; <--NEEDED IF USING GUI-->
    [SerializeField] private GameObject continueArrow; //SIGNALS IF MORE TEXT AVAILABLE
    [SerializeField] private TextMeshProUGUI dialogueText;
    NewControls controls;
    private Story currentStory;
    private int newScore; //THIS INTEGER IS UPDATED FROM GM
    private int prevScore; //THIS INTEGER IS USED TO COMPARE AGAINST THE GAMEMANAGER'S SCORE

    [Header("Ink JSON")]
    [SerializeField] private TextAsset inkJSON;

    public bool dialogueIsPlaying { get; private set; }

    //A static instance of this class (why is this needed? So this is accessible for all objects)
    private static TopDialogue instance;

    //Awake called when object activated
    private void Awake()
    {
    if (instance != null)
        {
            Debug.LogWarning("More than 1 TopDialogue Manager in the scene");
        }
    //initalises an instance of this class if only one exists
    instance = this;

    if (controls == null)
        {
            controls = new NewControls();
        }
        controls.Controls.Enable(); 
    }

// Start is called before the first frame update
void Start()
    {
        currentStory = new Story(inkJSON.text);
        dialogueText.text = "Quiet so far...";
        prevScore = 0;
        newScore = 0;
        dialogueIsPlaying = true;
        continueArrow.SetActive(false);
        //don't forget to enable GUI elements if using them! 
    }

    // Update is called once per frame
    void Update()
    {
        newScore = GameObject.Find("GameManager").GetComponent<GameManager>().gMScore;
        //return right away if no dialogue
        if (!dialogueIsPlaying)
        {
            return;
        }

        //Ideally, I want this to be a coroutine... not in update...
        //handle continuing to the next line in the dialogue when submit is pressed 
        if (prevScore<newScore)
        {
            print("Hurrah!");
            prevScore = newScore;
            ContinueStory();
            if (currentStory.canContinue)
            {
                continueArrow.SetActive(true);
            }
            else continueArrow.SetActive(false);
        }
    }

    private void ContinueStory()
    //Built in INK method that checks if there's another line
    {
        if (currentStory.canContinue)
        {
            dialogueText.text = currentStory.Continue();
        }
        else
        {
            //Because Exit Dialogue is IENumerator with a wait, it's a coroutine
            StartCoroutine(ExitDialogueMode());
        }
    }

    private IEnumerator ExitDialogueMode()//IENumerator to enable small wait
    {
        yield return new WaitForSeconds(0.2f);//Small wait to prevent button overlap

        dialogueIsPlaying = false;
        //dialoguePanel.SetActive(false);<--GUI-->
        //dialogueText.enabled = false;<--FOR OVERRIDE-->
        dialogueText.text = "";
    }

}

