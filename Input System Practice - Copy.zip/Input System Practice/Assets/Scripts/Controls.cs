using UnityEngine;


public class Controls : MonoBehaviour 
{
    NewControls controls;


    //public InputAction Move; //reference the c# generated input action in 'New Controls'
    //public InputAction Jump;
    Rigidbody2D rb; //reference the player's rigid body
    public float movementSpeed; //the player's movement speed
    Vector3 mv;
    public float jumpPower;
    public float maxJump;
    public float maxSpeed;
    public SpriteRenderer character;
    public Animator animator;
    bool facingLeft = true;
    Vector3 lastGround = Vector3.zero; //I hope to have a 'Fez' like system where the last ground you touch is what you respawn at. It sort of works! 


    private void Awake()
    {
        if (controls == null)
        {
            controls = new NewControls();
        }
        controls.Controls.Enable();
    }

    public void OnEnable()
    
    {
        //get the reference to the rigidbody
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        //Prevents unlimited jumping by making it that jump force can only be applied when current vertical velocity is 0. 
        //In other words, can only jump if completely still. 
        //However, I want some degree of change here... 
        if (rb.velocity.y == 0&&controls.Controls.Jump.IsPressed())
        {
            JumpCharacter();
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (controls.Controls.Quit.WasPressedThisFrame())
        {
            Quit(); 
        }

        if (rb.position.y < -10)
        {
            rb.position = lastGround;
        }

        if (DialogueManager.GetInstance().dialogueIsPlaying)
        {
            return;
        }
        WalkAnim();

        //Sets max speed character can accelerate until
        if (Mathf.Abs(rb.velocity.x) < maxSpeed)
            {
                MoveCharacter();
            }

      

    }

    private void MoveCharacter() 
    {
        
        //Get the movement direction
        var playerMovementDirection = controls.Controls.Move.ReadValue<Vector2>();
        
        //Move the character
        Vector2 force = new Vector2(playerMovementDirection.x * movementSpeed, 0f);
        
        rb.AddForce(force, ForceMode2D.Impulse);

        //Flip the character
        if (playerMovementDirection.x < 0f && facingLeft)
        { 
            Flip(); 
        }
        if (playerMovementDirection.x > 0f && !facingLeft)
        {
            Flip();
        }
    }

    private void JumpCharacter()
    {
        var playerJump = controls.Controls.Jump.ReadValue<Vector2>();
            Vector2 jumpForce = new Vector2(0f, playerJump.y * jumpPower);
            print(jumpForce);
            rb.AddForce(jumpForce, ForceMode2D.Impulse);
    }

    private void WalkAnim()
    {
        if (Mathf.Abs(rb.velocity.x) < 0.5)
        {
            animator.SetBool("isWalking", false);
        }
        else { animator.SetBool("isWalking", true); }
    }
    private void Flip()
    { 
        character.flipX = !character.flipX; //because the character model faces left, this is flipped from what you would think.
        facingLeft = !facingLeft;    
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
       lastGround = col.gameObject.transform.position;
    }

    private void Quit()
    {
            Application.Quit();
       
    }

}
