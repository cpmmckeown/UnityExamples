using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Tilemaps;

public class HelloCollide : MonoBehaviour
{
    private GameManager gameManager;
    
    private void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        Destroy(this.gameObject);
        gameManager.UpdateScore(5);
    }
}
